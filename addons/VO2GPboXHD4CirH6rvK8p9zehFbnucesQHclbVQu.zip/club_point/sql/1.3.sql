ALTER TABLE `club_points` ADD `order_id` INT NOT NULL AFTER `points`;
COMMIT;
